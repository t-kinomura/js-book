// フルーツを定義するクラス
class Fruit {
    private _name: string = '';
    public price: number = 0;
}

// 書籍を定義するクラス
class Book {
    public book_name: string = '';
    private price: number = 0;
}
