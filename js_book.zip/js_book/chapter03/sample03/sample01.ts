function sum(a, b) {
    return a * b;
}

let answer = sum(5, 2);
console.log(answer);
