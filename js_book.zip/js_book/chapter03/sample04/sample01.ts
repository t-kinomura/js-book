let color: '赤' | '青' | '黄';

color = '赤';
color = '黒';
