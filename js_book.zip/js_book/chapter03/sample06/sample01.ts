class Book {
    private name: string = '';
}

let mybook = new Book();
mybook.name = 'JavaScript入門'; 
