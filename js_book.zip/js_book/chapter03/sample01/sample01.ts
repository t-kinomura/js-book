// プロンプトでメッセージを入力する
let message = 'TypeScriptを勉強中です';

// コンソールに表示する
console.log(message);

