// プロンプトでメッセージを入力する
var message = 'TypeScriptを勉強中です';
// コンソールに表示する
console.log(message);
