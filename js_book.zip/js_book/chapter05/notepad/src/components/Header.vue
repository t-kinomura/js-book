<template>
  <header>
    <h1><slot></slot></h1>
  </header>
</template>

<script>
export default {
  name: 'Header'
}
</script>